<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Carousel;
use Illuminate\Http\Request;

class CarouselController extends Controller
{
    public function index()
    {
        $carousels = Carousel::orderByDesc('id')->get();
        return view('admin.carousel.index', compact('carousels'));
    }

    public function create()
    {
        return view('admin.carousel.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'        => 'required|string|max:255',
            'description'  => 'required|string',
            'button_text'  => 'required|string',
            'button_link'  => 'required|url',
            'image'        => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $imageName = time() . '.' . $request->image->extension();
        $request->image->move(public_path('uploads'), $imageName);

        Carousel::create([
            'title'       => $request->title,
            'description' => $request->description,
            'button_text' => $request->button_text,
            'button_link' => $request->button_link,
            'image_url'   => 'uploads/' . $imageName,
        ]);

        return redirect()->route('admin.carousel.index')
            ->with('success', 'Carousel item created successfully.');
    }

    public function edit(Carousel $carousel)
    {
        return view('admin.carousel.edit', compact('carousel'));
    }

    public function update(Request $request, Carousel $carousel)
    {
        $request->validate([
            'title'        => 'required|string|max:255',
            'description'  => 'required|string',
            'button_text'  => 'required|string',
            'button_link'  => 'required|url',
            'image'        => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('image')) {
            if ($carousel->image_url && file_exists(public_path($carousel->image_url))) {
                unlink(public_path($carousel->image_url));
            }

            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('uploads'), $imageName);

            $carousel->image_url = 'uploads/' . $imageName;
        }

        $carousel->update([
            'title'       => $request->title,
            'description' => $request->description,
            'button_text' => $request->button_text,
            'button_link' => $request->button_link,
        ]);

        return redirect()->route('admin.carousel.index')
            ->with('success', 'Carousel updated successfully.');
    }

    public function destroy(Carousel $carousel)
    {
        if ($carousel->image_url && file_exists(public_path($carousel->image_url))) {
            unlink(public_path($carousel->image_url));
        }

        $carousel->delete();

        return redirect()->route('admin.carousel.index')
            ->with('success', 'Carousel deleted successfully.');
    }
}
