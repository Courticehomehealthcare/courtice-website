<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ContactUs;

class ContactUsController extends Controller
{
    public function index()
    {
        $contacts = ContactUs::orderByDesc('Created_at')->get();
        return view('admin.contacts.index', compact('contacts'));
    }

    public function show(ContactUs $contact)
    {
        return view('admin.contacts.show', compact('contact'));
    }

    public function destroy(ContactUs $contact)
    {
        $contact->delete();
        return redirect()->route('admin.contacts.index')
            ->with('success', 'Contact message deleted.');
    }
}
