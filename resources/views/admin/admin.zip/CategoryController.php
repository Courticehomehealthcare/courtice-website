<?php 
// app/Http/Controllers/CategoryController.php
namespace App\Http\Controllers;
use App\Lib\JsonResponse;
use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    	private $jsonResponse;
	public function __construct() {
		$this->jsonResponse = new JsonResponse();
	}
    // Fetch all categories with subcategories
    public function index()
    {
        $categories = Category::with('subcategories')->get();
        return response()->json([
            'success' => true,
            'data' => $categories
        ]);
    }

    // Fetch a single category with its subcategories
    public function show($id)
    {
        $category = Category::with('subcategories')->find($id);

        if (!$category) {
            return response()->json([
                'success' => false,
                'message' => 'Category not found'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $category
        ]);
    }

    // Create a new category
    public function store(Request $request)
    {
        $request->validate([
            'categoriename' => 'required|string|unique:categories',
            'slug' => 'required|string|unique:categories',
        ]);

        $category = Category::create($request->only(['categoriename', 'slug', 'description']));

        return response()->json([
            'success' => true,
            'data' => $category
        ]);
    }

    // Update an existing category
    public function update(Request $request, $id)
    {
        $category = Category::find($id);

        if (!$category) {
            return response()->json([
                'success' => false,
                'message' => 'Category not found'
            ], 404);
        }

        $request->validate([
            'categoriename' => 'required|string|unique:categories,categoriename,' . $id,
            'slug' => 'required|string|unique:categories,slug,' . $id,
        ]);

        $category->update($request->only(['categoriename', 'slug', 'description']));

        return response()->json([
            'success' => true,
            'data' => $category
        ]);
    }

    // Delete a category
    public function destroy($id)
    {
        $category = Category::find($id);

        if (!$category) {
            return response()->json([
                'success' => false,
                'message' => 'Category not found'
            ], 404);
        }

        $category->delete();

        return response()->json([
            'success' => true,
            'message' => 'Category deleted successfully'
        ]);
    }


    public function Getall(Request $request)    {
        $category = Category::get();
        $data = [];
        if ($category->isNotEmpty()) {
            return $this->jsonResponse->createResponse(
                $category,
                true, 
                'category Listed loaded!',
                200				
            );
        }
        return $this->jsonResponse->createResponse(
            [], 
            false, 
            'No data!',
            200				
        );
    }
    
     public function shows($id)
    {
                $subCat = Subcategory::where('category_id', $id)->get();
           $data = [];
            if ($subCat->isNotEmpty()) {
        foreach ($subCat as $key => $subCat) {
            $data[] = $subCat;
        }
        return $this->jsonResponse->createResponse(
            $data,
            true,
            'Sub Categories  loaded! Successfully',
            200
        );
    }
    return $this->jsonResponse->createResponse(
        [],
        false,
        'No data!',
        200
    );
        // if (!$subCat) {
        //     return response()->json(['message' => 'Sub-category not found'], 404);
        // }

        // return response()->json($subCat);
    }
    
    
    // Create a new subcategory
    public function storeSubcategory(Request $request)
    {
        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'subcategoriename' => 'required|string|unique:subcategories',
            'slug' => 'required|string|unique:subcategories',
        ]);

        $subcategory = Subcategory::create($request->only(['category_id', 'subcategoriename', 'slug', 'description']));

        return response()->json([
            'success' => true,
            'data' => $subcategory
        ]);
    }

    // Update a subcategory
    public function updateSubcategory(Request $request, $id)
    {
        $subcategory = Subcategory::find($id);

        if (!$subcategory) {
            return response()->json([
                'success' => false,
                'message' => 'Subcategory not found'
            ], 404);
        }

        $request->validate([
            'subcategoriename' => 'required|string|unique:subcategories,name,' . $id,
            'slug' => 'required|string|unique:subcategories,slug,' . $id,
        ]);

        $subcategory->update($request->only(['subcategoriename', 'slug', 'description']));

        return response()->json([
            'success' => true,
            'data' => $subcategory
        ]);
    }

    // Delete a subcategory
    public function destroySubcategory($id)
    {
        $subcategory = Subcategory::find($id);

        if (!$subcategory) {
            return response()->json([
                'success' => false,
                'message' => 'Subcategory not found'
            ], 404);
        }

        $subcategory->delete();

        return response()->json([
            'success' => true,
            'message' => 'Subcategory deleted successfully'
        ]);
    }
}
